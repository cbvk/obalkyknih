package cz.rumanek.ocr.abby;

import cz.rumanek.ocr.abby.wsdl.FileContainer;
import cz.rumanek.ocr.abby.wsdl.OutputDocument;
import cz.rumanek.ocr.abby.wsdl.RSSoapService;
import cz.rumanek.ocr.abby.wsdl.RSSoapServiceSoap;
import cz.rumanek.ocr.abby.wsdl.XmlResult;
import org.apache.commons.io.IOUtils;

import java.util.ArrayList;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

public class App
{
    public static void main( String[] args )
    {
        File file = new File(args[0]);
        FileInputStream fis = null;
        String ocrAlto = null;
        String ocrTxt = null;
        try {
            fis = new FileInputStream(file);
            RSSoapService service = new RSSoapService();
            RSSoapServiceSoap soap = service.getRSSoapServiceSoap();
            FileContainer data = new FileContainer();
            data.setFileContents(IOUtils.toByteArray(fis));
            XmlResult result = soap.processFile("localhost", "obalky-knih", data);

            if (result.isIsFailed()) {
                System.out.println("Chyba");
            }

//			ArrayList l = result.getInputFiles().getInputFile().get(0).getOutputDocuments().getOutputDocument();
//			for(int i=0;i<l.size();i++) {
//				OutputDocument document = (OutputDocument)l.get(i);
            for (OutputDocument document :result.getInputFiles().getInputFile().get(0).getOutputDocuments().getOutputDocument()) {
                if ("OFF_ALTO".equals(document.getFormatSettings().getFileFormat().toString())) {
                    try {
                        ocrAlto = new String(document.getFiles().getFileContainer().get(0).getFileContents(), "UTF-8");
                        System.out.println(ocrAlto);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
                if ("OFF_TEXT".equals(document.getFormatSettings().getFileFormat().toString())) {
                    try {
                        ocrTxt = new String(document.getFiles().getFileContainer().get(0).getFileContents(), "UTF-8");
                        System.out.println(ocrTxt);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }  catch (IOException e) {
            e.printStackTrace();
        }

    }
}
