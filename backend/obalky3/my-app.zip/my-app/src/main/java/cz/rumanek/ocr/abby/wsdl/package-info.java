@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.abbyy.com/RecognitionServer3_xml/RecognitionServer3.xml", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cz.rumanek.ocr.abby.wsdl;
